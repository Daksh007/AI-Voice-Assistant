from django.shortcuts import render, HttpResponse, redirect
import os
import speech_recognition as sr
import pyttsx3
import wikipedia
# import pyjokes
import datetime
# from selenium.webdriver import Firefox
# from selenium.webdriver.firefox.options import Options
import time
import webbrowser
# import ctypes
import wolframalpha
import pytz
from datetime import datetime

query = ""
response = ""

def index(request):
    return render(request,'info/index.html')



def speak(audio, sleep_time):
    # engine = pyttsx3.init()
    # # voices = engine.getProperty('voices')
    # # engine.setProperty('voice',voices[1].id)
    # # newVoiceRate = 145
    # # engine.setProperty('rate', newVoiceRate)
    # engine.setProperty('rate', 150)
    # # Set volume 0-1
    # engine.setProperty('volume', 0.7)
    # engine.say("Welcome")
    # engine.say("Rohit Jumnani")
    # engine.runAndWait()

    # print("done............................................")
    converter = pyttsx3.init()
    converter.setProperty('rate', 150)
    converter.setProperty('volume', 0.7)
    print("I am speaking : ", audio)
    converter.say(audio)
    converter.runAndWait()
    sleep_time = max(sleep_time, len(response)/10 + 1)
    time.sleep(sleep_time)



def listen(request):
    global query
    print("Debug : Listen Function called")
    query = takecommand()
    query = query.lower()
    print(query)
    print("Debug Log 2 ==> ", query)
    global response
    response = "Sorry I was unable to understand your command"
    if(query=='none'):
        query = "Please say that again"
        return redirect('listened',stage=10, time = 3)
    elif "wish me " in query:
        response = "Good Afternoon"
        return redirect('listened',stage=0, time = 4)
    elif "your name" in query:
        response = "My name is ,STORM"
        return redirect('listened',stage=0, time = 3)
    elif "who are you" in query:
        response = "I am your Voice Assistant,STORM"
        return redirect('listened',stage=0, time = 4)
    # elif ("who" in query) and ("the" in query):
    #     response = "I am your fucking voice assistant,STORM"
    #     return redirect('listened',stage=0, time=4)
    elif "stop listening" in query:
        speak('Listening stopped',3)
        return redirect('index')
    # elif "play music" in query:
    #     speak('Playing Music')
    #     music_dir = 'R:\\songs'
    #     all_songs = os.listdir(music_dir)
    #     print(all_songs)
    #     os.startfile(os.path.join(music_dir , all_songs[0]))
    #     return redirect('index')
    elif ("what" in query) and ("time" in query):
        #  current_time = datetime.datetime.now().strftime("%H:%M:%S")
         IST = pytz.timezone('Asia/Kolkata')
         current_time = datetime.now(IST)
         x = current_time.strftime('%H:%M:%S')
         response = f"The time is {x}"
         return redirect('listened',stage=0,time=7)
    # elif "joke" in query:
    #     My_joke = pyjokes.get_joke(language="en", category="neutral")
    #     response = My_joke
    #     return redirect('listened',stage=0)
    elif "wikipedia" in query:
        query = query.replace('wikipaedia',"")
        results = wikipedia.summary(query,sentences =2)
        speak("According to Wikipedia", 2)
        print(results)
        response = results
        return redirect('listened',stage=0, time = len(response)/10+2)
    # elif "play" in query:
    #     query = query.replace('play','')
    #     query = query.replace('song','')
    #     query = query.replace(' ','+')

    #     print(query)

    #     opts = Options()
    #     opts.headless = False
    #     browser = Firefox(options=opts)
    #     browser.get("https://www.youtube.com/results?search_query="+query)
    #     time.sleep(2)
    #     box = browser.find_elements_by_class_name('style-scope ytd-thumbnail')
    #     box[0].click()
    #     tym = browser.find_elements_by_class_name('ytd-thumbnail-overlay-time-status-renderer')
    #     print(tym)
    #     time.sleep(20)
    #     browser.close()
    #     print('Done')
    #     print(len(tym))
    #     return redirect('listen')
    elif 'open youtube' in query:
        webbrowser.open_new("https://www.youtube.com/")
        speak("Opening Youtube", 3)
        return redirect('index')
    elif 'play' in query:
        # speak("Playing", 2)
        webbrowser.open_new("https://www.youtube.com/watch?v=vKb9xwSRrsU")
        return redirect('index')

    elif 'open google' in query:
        speak("Here you go to Google\n", 3)
        webbrowser.open("google.com")
        return redirect('index')

    elif 'open stackoverflow' in query:
        speak("Here you go to Stack Over flow.Happy coding")
        webbrowser.open("stackoverflow.com", 3)
        return redirect('index')

    elif "who made you" in query or "who created you" in query:
        response = 'I have been created by Rohit Jumnani'

        return redirect('listened',stage=0,time=4)

    elif 'is love' in query:
        speak("It is 7th sense that destroy all other senses", 4)
        return redirect('listen')

    elif 'search' in query:

        query = query.replace("search", "")
        query = query.replace("play", "")
        webbrowser.open(query)
        return redirect('index')

    # elif 'window' in query:
    #     speak("locking the device")
    #     ctypes.windll.user32.LockWorkStation()
    #     return redirect('index')

    app_id = '72YUKU-4L3YQTQK87'
    client = wolframalpha.Client(app_id)

    # Includes only text from the response
    try:
        res = client.query(query)
        response = next(res.results).text
        return redirect('listened',stage=0,time=5)
    except:
        return render(request,'info/listened.html',{'query':query,'stage':0,'time':4})


def listened(request, stage, time):
    print("Debug Log 3 (stage) ==> ",stage)
    print("Debug Log 4 (query) ==> ",query)
    print("Debug Log 5 (time ) ==> ", time)
    if(stage == 0):
        return render(request,'info/listened.html',{'query':query,'stage':0,'time' : time})
    elif(stage == 1):
        if(response!=""):
            speak(response, time)
        return render(request,'info/listened.html',{'query':'none','stage':1,'time':time})
    return render(request,'info/listened.html',{'query':query,'stage':stage,'time':time})


def takecommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.pause_threshold = 0.8
        r.adjust_for_ambient_noise(source,duration=0.5)
        print('Listening...')
        audio_file = r.record(source,duration=4)
        print("___")
    try:
        query = r.recognize_google(audio_file,language='en-in')
        print(query)

    except Exception as e:
        print(e)
        print("Please say That Again..!!")
        print("Debug Log 1")
        return "None"
    return query

def phase2(request):
    return render(request,'info/base2.html',{'query':"Please say that again",'stage':2})

